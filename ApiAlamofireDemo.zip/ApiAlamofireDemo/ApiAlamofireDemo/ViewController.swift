//
//  ViewController.swift
//  ApiAlamofireDemo
//
//  Created by Nirav Joshi on 16/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import Alamofire_SwiftyJSON
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    
    
    @IBOutlet weak var tblList: UITableView!
    var ArytblList = [[String:Any]]()
    
/*
    // api list for this link
    https://github.com/typicode/jsonplaceholder#how-to
  GET https://jsonplaceholder.typicode.com/posts
     GET https://jsonplaceholder.typicode.com/posts/1
     
     POST
     
     // POST adds a random id to the object sent
     fetch('https://jsonplaceholder.typicode.com/posts', {
     method: 'POST',
     body: JSON.stringify({
     title: 'foo',
     body: 'bar',
     userId: 1
     }),
     headers: {
     "Content-type": "application/json; charset=UTF-8"
     }
     })
     .then(response => response.json())
     .then(json => console.log(json))
     
     /* will return
     {
     id: 101,
     title: 'foo',
     body: 'bar',
     userId: 1
     }
     */
     
    */
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let people = ["Matt", "Rich", "Mary", "Mike", "Karin", "Phil", "Edward", "Ken"]
        
        // Group people into arrays with the first letter of their name as the key
        // https://developer.apple.com/documentation/swift/dictionary/2893436-init
        // Xcode 9 / Swift 4 (Proposal 165)
        let groupedNameDictionary = Dictionary(grouping: people, by: { $0.characters.first! })
        print(groupedNameDictionary)
        
        // Group the people array into arrays with similar length and the integer length as the key for the dictionary
        // https://github.com/apple/swift-evolution/blob/master/proposals/0165-dict.md#2-key-based-subscript-with-default-value
        // Xcode 9 / Swift 4 (Proposal 165)
        let groupedLengthDictionary = Dictionary(grouping: people) { $0.utf16.count }
        print(groupedLengthDictionary)
        
//        tblList.register(ListTableCell.self, forCellReuseIdentifier: "ListTableCell")
        tblList.rowHeight = 88.0
        tblList.estimatedRowHeight = UITableView.automaticDimension
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        callWS()
    }
    
    func  callWS() {
        Alamofire.request("https://jsonplaceholder.typicode.com/posts", method: .get, parameters: nil, encoding: URLEncoding.default, headers: nil).responseSwiftyJSON { (response) in
         //   print("\(response.result.value!)")
            
            if let data = response.result.value
            {
                self.ArytblList = data.arrayObject as! [[String : Any]]
                print(self.ArytblList[0]["title"] as! String)
                self.tblList.reloadData()
            }
        }
    }


    // MARK:- tableview delegate and datasource
 
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ArytblList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "ListTableCell", for: indexPath) as! ListTableCell
        
        print(ArytblList[indexPath.row]["title"] as! String)
        let dic = ArytblList[indexPath.row]      
        cell.lblTitle.text = (dic["title"] as! String)
        cell.lblBody.text = (dic["body"] as! String) 
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}

