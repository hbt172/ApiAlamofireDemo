//
//  ListTableCell.swift
//  ApiAlamofireDemo
//
//  Created by Nirav Joshi on 16/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ListTableCell: UITableViewCell {

    @IBOutlet var lblBody: UILabel!
    @IBOutlet var lblTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
