//
//  AddDataVC.swift
//  ApiAlamofireDemo
//
//  Created by Nirav Joshi on 16/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import Alamofire_SwiftyJSON
class AddDataVC: UIViewController {
    @IBOutlet weak var txtUserID: UITextField!
    
    @IBOutlet weak var txtBody: UITextField!
    @IBOutlet weak var txtTitle: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func callWS(strUserID : String,strTitle : String,strBody : String)  {
        Alamofire.request("https://jsonplaceholder.typicode.com/posts", method: .post, parameters: [ "title" : strTitle,"body": strBody,                                                                                                    "userId": strUserID], encoding: JSONEncoding.default, headers: [ "Content-type" : "application/json; charset=UTF-8"]).responseSwiftyJSON { (response) in
            print(response)
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func btnAddClick(_ sender: Any) {
        callWS(strUserID: txtUserID.text!, strTitle: txtTitle.text!, strBody: txtBody.text!)
    }
    
    @IBAction func btnCancelClick(_ sender: Any) {
    }
    
}
